from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton



#-------MenuOnRu-------
reply_ru_bnt1 = KeyboardButton('ℹ️ Информация о нас')
reply_ru_bnt2 = KeyboardButton('📊 График работы')
reply_ru_bnt3 = KeyboardButton("📍 Локация")
reply_ru_bnt5 = KeyboardButton("💰 Цены")
reply_ru_bnt6 = KeyboardButton('✍️ Отзывы и предложения')
markup2 = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
markup2.add(reply_ru_bnt1, reply_ru_bnt2, reply_ru_bnt3,
            reply_ru_bnt5, reply_ru_bnt6)
