import asyncio
from aiogram.dispatcher.filters import Text
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State


import keyboards as kb
from config import token


storage = MemoryStorage()
bot = Bot(token=token, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot, storage=storage)

class FSM(StatesGroup):
    feedback = State()

@dp.message_handler(commands=['start'])
async def process_command_start(message):
    await message.answer(f"Привет *{message.from_user.first_name}*\n"
                         "Добро пожаловать в школу", parse_mode=types.ParseMode.MARKDOWN, reply_markup=kb.markup2)


@dp.message_handler(Text(equals="ℹ️ Информация о нас"))
async def process_command_info(message: types.Message):
    await message.answer("ℹ️ Информация о нас дурак")

#----Rumenu----
@dp.message_handler(Text(equals="📊 График работы"))
async def process_command_work(message: types.Message):
    await message.answer("📊 График работы", reply_markup=kb.markup2)



@dp.message_handler(Text(equals="📍 Локация"))
async def send_location(message: types.Message):
        location_url = "https://maps.google.com/maps?q=41.315645,69.217151&ll=41.315645,69.217151&z=16"  # Замените эту ссылку на вашу локацию
        await message.reply(f"Вот ссылка на локацию: {location_url}")



@dp.message_handler(Text(equals='💰 Цены'))
async def process_command_1(message: types.Message):
    await message.answer("💰 Цены", reply_markup=kb.markup1)

#---Go_Out_RuMenu----
@dp.message_handler(Text(equals='✍️ Отзывы и предложения'))
async def process_command_1(message: types.Message):
    await message.answer("Скоро...", reply_markup=kb.markup2)





if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    executor.start_polling(dp)