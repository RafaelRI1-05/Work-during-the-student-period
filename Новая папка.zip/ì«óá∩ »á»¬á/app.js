let close = document.querySelector("#close")
let open = document.querySelector("#open")
let text0 = document.querySelector(".close")


function openclose(){
    text0.style.display="none"
    close.style.display="none"
    open.style.display="block"

}
function closeopen(){
    text0.style.display="block"
    close.style.display="block"
    open.style.display="none"

}
let close1 = document.querySelector("#close1")
let open1 = document.querySelector("#open1")
let text1 = document.querySelector(".open")


function openclose1(){
    text1.style.display="none"
    close1.style.display="none"
    open1.style.display="block"

}
function closeopen1(){
    text1.style.display="block"
    close1.style.display="block"
    open1.style.display="none"

}

let close2 = document.querySelector("#close2")
let open2 = document.querySelector("#open2")
let text2 = document.querySelector(".open2")



function openclose2(){
    text2.style.display="none"
    close2.style.display="none"
    open2.style.display="block"
}
function closeopen2(){
    text2.style.display="block"
    close2.style.display="block"
    open2.style.display="none"
}

let close3 = document.querySelector("#close3")
let open3 = document.querySelector("#open3")
let text3 = document.querySelector(".open3")



function openclose3(){
    text3.style.display="none"
    close3.style.display="none"
    open3.style.display="block"
}
function closeopen3(){
    text3.style.display="block"
    close3.style.display="block"
    open3.style.display="none"
}

let close4 = document.querySelector("#close4")
let open4 = document.querySelector("#open4")
let text45 = document.q4erySelector(".open5")



function openclose4(){
    text45.style.display="none"
    close4.style.display="none"
    open4.style.display="block"
}
function closeopen4(){
    text45.style.display="block"
    close4.style.display="block"
    open4.style.display="none"
}

